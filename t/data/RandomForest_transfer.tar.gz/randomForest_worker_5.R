## this is using work published in
## Tao Shi and Steve Horvath (2006) Unsupervised Learning with Random Forest Predictors. 
## Journal of Computational and Graphical Statistics. Volume 15, Number 1, March 2006, pp. 118-138(21)
lock.name <- 'randomForest_worker_5.Rdata'
source ('libs/Tool_RandomForest.R')
source ('libs/Tool_grouping.R')
if ( ! identical( lock.name, paste('randomForest_worker_NUM','BER.Rdata', sep='') ) ) {
  set_lock( lock.name )
}
load ('norm_data.RData')
no.forests=7
no.trees=433
datRF <- data.frame(cbind( data.filtered$z$PCR, data.filtered$FACS ))
system.time (RF <- calculate_RF(  datRF, 7 , 433 ,imp=T, oob.prox1=T, mtry1=3 ))
save_RF(RF, 'randomForest_worker_5.Rdata' )
datRF <- data.frame(t(cbind( data.filtered$z$PCR, data.filtered$FACS )))
attach(datRF)
system.time (RF <- calculate_RF( datRF, 7 , 433 ,imp=T, oob.prox1=T, mtry1=3 ))
save_RF(RF, 'randomForest_worker_genes_5.Rdata' )
release_lock (lock.name)
