library(DESeq) 
library("biomaRt")
library(gplots)
library(RSvgDevice)
library(Rsubread)

read.bams <- function ( bamFiles, annotation, GTF.featureType='exon', GTF.attrType = "gene_id", isPairedEnd = FALSE, nthreads = 32){
	if (file.exists(bamFiles)){
		bamFiles <- readLines(bamFiles)
	}
	counts <- featureCounts(files =bamFiles,annot.ext = annotation ,isGTFAnnotationFile = TRUE,GTF.featureType = GTF.featureType,
		GTF.attrType = GTF.attrType,allowMultiOverlap=T, isPairedEnd =isPairedEnd , nthreads = nthreads)
	counts.tab <- cbind(counts$annotation,counts$counts)  # combine the annotation and counts
	write.table(counts.tab, "Tina_Quants_Refseq_Apr2015_mm10_hisat.txt", row.names = F, col.names = T, quote = F, sep = "\t")
	counts.tab
}

difference <- function ( x, clusters ) {
	ret = 0 
	for ( i in 1:max(clusters)  ) {
		a <- x[which( clusters == i)]
		a <- a[- (is.na(a))==F]
		if ( length(a) > 1 ) {  ret = ret + sum( (a- mean(a) )^2 ) }
	}
	ret
}

SumOfSquares.NGSexpressionSet <- function( x, phenotype ) {
	sos <- 0
	test = NULL
	if ( ! is.null(x$expr)){
		test <- x$expr
	}else{
		test <- log(exprs(x$vsdFull))
	}
	clusters <- as.numeric( x$samples[,phenotype])
	ret <- list ( 'per_expression' = apply(test,2, difference, clusters ) )
	sos <- round(sum(ret$per_expression))
	sos
}

subset.NGSexpressionSet <- function( x, column='Analysis', value=NULL, name='newSet', usecol='Use' ){
	S <- x$samples[which ( x$samples[, column] == value & x$samples[, usecol] == 1 ),]
	x$data <- x$data[, as.vector(S[, 'SampleName' ])]
	x$data <- x$data[, order(S$Order)  ]
	x$samples <- S
	x$name <- name
	if ( exists(where=x, 'vsdFull')){
		x$vsdFull <- NULL
		x$cds <- NULL
	}
	if ( exists(where=x, 'stats')){
		x$stats <- NULL
	}
	if ( exists(where=x, 'sig_genes')){
		x$sig_genes <- NULL
	}
	colnames(x$data) <- forceAbsoluteUniqueSample ( as.vector(S[, x$sampleNamesCol ]) )
	x$samples[,'SampleName'] <- colnames(x$data)
	write.table (S, file=paste(name,'_Sample_Description', ".xls", sep=''), sep='\t',  row.names=F,quote=F )
	x
}

createWorkingSet <- function ( dat, Samples,  Analysis = NULL, name='WorkingSet', namecol='GroupName', namerow= 'GeneID', usecol='Use' ) {
	S <- Samples
	annotation <- dat[, is.na(match( colnames(dat), as.vector(S$filename) ))==T ]
	if ( ! is.null(Analysis) ){
		S <- Samples[which ( Samples$Analysis == Analysis & Samples[, usecol] == 1 ),]
	}
	ret <- dat[, as.vector(S$filename) ]
	ret <- ret[, order(S$Order)  ]
	S <- S[order(S$Order), ]
	colnames(ret) <- forceAbsoluteUniqueSample ( as.vector(S[, namecol]) )
	S$SampleName <- colnames(ret)
	rownames(ret) <- annotation[,namerow]
	write.table (cbind(rownames(ret), ret ), file=paste(name, '_DataValues',".xls", sep=''), sep='\t',  row.names=F,quote=F )
	write.table (S, file=paste(name,'_Sample_Description', ".xls", sep=''), sep='\t',  row.names=F,quote=F )
	data <- list ( 'data' = ret, samples = S, name= name, annotation = annotation, rownamescol = namerow )
	data$sampleNamesCol <- namecol
	class(data) <- 'NGSexpressionSet'
	data$batchRemoved=0
	data
}

print.NGSexpressionSet <- function (x) {
	cat (paste("An object of class", class(x)),"\n" )
	cat("named ",x$name,"\n")
	cat (paste( 'with',nrow(x$data),'genes and', ncol(x$data),' samples.'),"\n")
	cat (paste("Annotation datasets (",paste(dim(x$data),collapse=','),"): '",paste( colnames(x$annotation ), collapse="', '"),"'  ",sep='' ),"\n")
	cat (paste("Sample annotation (",paste(dim(x$samples),collapse=','),"): '",paste( colnames(x$samples ), collapse="', '"),"'  ",sep='' ),"\n")
	if ( exists(where=x, 'vsdFull')){
		cat ( "expression values are preprocessed\n" )
	}
	if ( exists(where=x, 'stats')){
		cat ( "P values were calculated for ", length(names(x$stats)) -1, " condition(s)\n")
	}
	if ( exists(where=x, 'sig_genes')){
		cat ( "significant genes were accessed for ", length(names(x$sig_genes)), " p value(s)\n")
		cat ( paste( names(x$sig_genes)),"\n")
	}
}

# mart is a data table coming from a a call like
# mart <- getBM ( attributes=c('refseq_mrna',  'ensembl_gene_id', 'mgi_symbol' ), filters='refseq_mrna', values=dat[,1], mart=ensembl )
addAnnotation.NGSexpressionSet <- function(x ,mart, mart.col='refseq_mrna'){
	x$annotation <- cbind(x$annotation, mart[match(rownames(x$data),mart[,mart.col] ), ] )
	x
} 

forceAbsoluteUniqueSample <- function ( x ,separator='_') {
	last = ''
	ret <- vector(length=length(x))
	
	for ( i in 1:length(x) ){
		if ( is.null(ret) ){
			last = x[i]
			ret[i] <- last
		}
		else{
			last = x[i]
			if ( ! is.na(match( last, ret )) ){
				last <- paste(last,separator,sum( ! is.na(match( x[1:i], last )))-1, sep = '')
			}
			ret[i] <- last
		}
	}
	ret
}

do_comparisons.NGSexpressionSet <- function ( dataOBJ, geneNameCol= 'mgi_symbol') {
	if ( is.null(dataOBJ$stats) ){
		if ( exists(where=dataOBJ, 'vsdFull')){
			dataOBJ <- preprocess.NGSexpressionSet ( dataOBJ )
		}
		dataOBJ$stats <- list ( n = 0)
		na <- c('n')
		conditions <- as.vector(unique(dataOBJ$samples[,'GroupName']) )
		for ( i in 1:(length(conditions)-1) ){
			for ( a in (i+1):length(conditions) ){ 
				print ( paste( conditions[i], conditions[a], sep='_vs_') )
				dataOBJ$stats[[1]] = dataOBJ$stats[[1]]+1
				na[dataOBJ$stats$n+1] = paste( conditions[i], conditions[a],sep=' vs. ')
				dataOBJ$stats[[dataOBJ$stats[[1]]+1]] <- nbinomTest(dataOBJ$cds, conditions[i], conditions[a])
				write.table(
						data.frame( id = dataOBJ$stats[[dataOBJ$stats[[1]]+1]]$id ,
								GeneSymbol = as.vector (dataOBJ$annotation[is.na(match ( dataOBJ$annotation$GeneID, dataOBJ$stats[[dataOBJ$stats[[1]]+1]]$id ) ) == F, geneNameCol]), 
								dataOBJ$stats[[dataOBJ$stats[[1]]+1]][,-1] ), 
						file= paste( 'all_stats_', dataOBJ$name, na[dataOBJ$stats$n+1], '.xls',sep=''), 
						row.names=F, 
						sep="\t",
						quote=F 
				)
				dataOBJ$stats[[dataOBJ$stats[[1]]+1]] <- dataOBJ$stats[[dataOBJ$stats[[1]]+1]][which(dataOBJ$stats[[dataOBJ$stats[[1]]+1]]$padj < 0.2),] ## drop useless data
			}
		}
		names(dataOBJ$stats) <- na
	}
	dataOBJ
}

name_4_IDs.NGSexpressionSet <- function ( x, ids=NULL, geneNameCol='mgi_symbol' ) {
	if ( is.null(ids) ) {
		ids <- as.vector(colnames(x$data) )
	}
	as.vector(x$annotation[match( ids,x$annotation[, x$rownamescol]),geneNameCol])
}

get_gene_list.NGSexpressionSet <- function (x, p_value = c ( 0.1,  1e-2 ,1e-3,1e-4,1e-5, 1e-6, 1e-7, 1e-8 ), geneNameCol='mgi_symbol' ) {
	if ( exists(where=x, 'stats')){
		cmps <- names(x$stats)
		p_value <- as.numeric( p_value )
		x$sig_genes <- vector ('list', length(p_value))
		names( x$sig_genes ) <- as.vector(p_value)
		for ( p in 1:length(p_value)){
			x$sig_genes[[p]] <- vector ('list', length(cmps)-1)
			for ( i in 2:length(cmps) ){
				sig.genes <- x$stats[[i]][which(x$stats[[i]]$padj < p_value[p] ), ] 
				sig.names <- name_4_IDs.NGSexpressionSet( x, sig.genes[,1], geneNameCol)
				sig.tab <- cbind(sig.names,sig.genes ) 
				if ( ncol(sig.tab) > 0 ){
					write.table(sig.tab,paste(x$name,'_',cmps[i],p_value[p] ,".xls",sep=''),col.names=T,row.names=F,sep="\t",quote=F)
				}
				x$sig_genes[[p]][[i-1]] = list (id = sig.genes[,1], names=sig.names )
			}
			x$sig_genes[[p]]$all <- list( id = unique(unlist(lapply (x$sig_genes[[p]] , function(a) { a$id } ))), names= unique(unlist(lapply ( x$sig_genes[[p]], function(a) { a$names } ))) )
		}
	}
	x
}

plot.NGSexpressionSet <- function ( x, pvalue=c( 0.1,1e-2 ,1e-3,1e-4,1e-5, 1e-6, 1e-7, 1e-8 ), Subset=NULL , Subset.name= NULL, comp=NULL, gene_centered=F, collaps=NULL,geneNameCol= "mgi_symbol") {
	if ( !is.null(comp) ){
		print ("At the moment it is not possible to reduce the plotting to one comparison only" )
		return (x)
	}
	add = ''
	orig.name = x$name
	if ( gene_centered ) {
		add = 'GenesOnly'
	}
	#browser()
	if ( ! is.null(collaps)){
		if ( nchar(add) > 1 ){
			add = paste( 'mean', add, sep='_')
		}else{
			add = 'mean'
		}
	}
	if ( ! is.null(Subset) ){
		if ( is.null(Subset.name)){
			Subset.name = 'subset_name_unset'
		}
		if ( nchar(add) > 1 ){
			add = paste( add, Subset.name,sep='_')
		}else{
			add = Subset.name
		}
	}
	if ( nchar(add) > 0 ){
		x$name = paste( add,x$name, sep='_')
	}
	print ( x$name )
	for (i in match( names(x$sig_genes), pvalue ) ){
		try( plot.heatmaps( 
						x, 
						x$sig_genes[[i]],
						names(x$sig_genes)[i],
						analysis_name = paste (x$name, version), 
						gene_centered = gene_centered,
						Subset = Subset,
						collaps = collaps,
						geneNameCol= geneNameCol
		), silent=F)
	}
	x$name = orig.name
}


plot.heatmaps <- function ( dataOBJ, gene.names , pvalue=1, analysis_name ='Unnamed', gene_centered = F, Subset=NULL, collaps=NULL,geneNameCol= "mgi_symbol" ) {
	exprs = NULL
	if ( ! is.null(dataOBJ$expr)){
		exprs <- dataOBJ$expr
	}else{
		exprs <- exprs(dataOBJ$vsdFull)
	}
	geneNamesBased <- exprs[is.na(match(rownames(exprs),gene.names$all$id ))==F,]
	geneNamesBased <- data.frame ( 'GeneSymbol' = as.vector (dataOBJ$annotation[is.na(match ( dataOBJ$annotation$GeneID, gene.names$all$id ) ) == F, geneNameCol]),  geneNamesBased) 
	if ( ! is.null(Subset) ) { ## subset is a list of srings matching to the gene symbols
		useful <- NULL
		for ( i in 1:length(Subset) ){
			useful <- c( useful, grep(Subset[i], geneNamesBased[,1] ) )
		}
		if ( length(useful) > 0 ){
			geneNamesBased <- geneNamesBased[ unique(useful), ]
		}
	}
	if ( gene_centered ){
		ok <- as.vector(which ( is.na(geneNamesBased[,1] )))
		grepped <- grep('_drop',forceAbsoluteUniqueSample(as.vector(geneNamesBased[,1]), '_drop_' ))
		if ( length(ok) > 1 ){
			geneNamesBased <- geneNamesBased[- grepped [ - match ( ok[-1] , grepped ) ], ]
		}
		else if ( length(grepped) > 0 ) {
			geneNamesBased <- geneNamesBased[-grepped, ]
		}
		
		fname = paste( 'GenesOnly_',dataOBJ$name,sep='')
	}
	rn <- rownames(geneNamesBased)
	if ( ! is.null(collaps)){
		u <- unique(as.vector(dataOBJ$samples$GroupName))
		m <- length(u)
		mm <-  matrix ( rep(0,m * nrow(geneNamesBased)), ncol=m)
		colnames(mm) <- u
		rownames(mm) <- rownames(geneNamesBased)
		for ( i in u ){
			## calculate the mean expression for each gene over all cells of the group
			mm[,i] <- apply( geneNamesBased[ , which(as.vector(dataOBJ$samples$GroupName) == i )+1],1,mean)
		}
		geneNamesBased <- data.frame( GeneSymbol = as.vector(geneNamesBased[,1]), mm )
	}
	write.table( data.frame ( 'GeneSymbol' = rownames(geneNamesBased),geneNamesBased[,-1]),file= paste(fname,'_HeatmapID_',pvalue,'_data4Genesis.txt', sep=''),sep='\t', row.names=F,quote=F  )
	write.table(  geneNamesBased, file= paste(fname,'_Heatmap_GeneSymbols_',pvalue,'_data4Genesis.txt', sep=''),sep='\t', row.names=F,quote=F  )
	if ( nrow(geneNamesBased) > 1 ){
		geneNamesBased <- read.delim( file= paste(fname,'_Heatmap_GeneSymbols_',pvalue,'_data4Genesis.txt', sep=''), header=T )
		rownames(geneNamesBased) <- rn
		s <- ceiling(20 * nrow(geneNamesBased)/230 )
		if ( s < 5 ) {s <- 5}
		print (paste ("Height =",s))
		fname= dataOBJ$name
		devSVG( file=paste(dataOBJ$name,"_Heatmap_IDs_",pvalue,".svg",sep='') ,width=10,height=s)
		print ( paste ("I create the figure file ",fname,"_Heatmap_IDs_",pvalue,".svg",sep=''))
		heatmap.2(as.matrix(geneNamesBased[,-1]), lwid = c( 1,6), lhei=c(1,5), cexRow=0.4,cexCol=0.7,col = greenred(30), trace="none", margin=c(10, 10),dendrogram="row",scale="row",
				distfun=function (x) as.dist( 1- cor(t(x), method='pearson')),Colv=F, main=paste( analysis_name, pvalue ))	
		dev.off()
		rownames(geneNamesBased) <- paste(geneNamesBased[,1] , rownames(geneNamesBased) )
		devSVG( file=paste(fname,"_Heatmap_GeneSymbols_",pvalue,".svg",sep='') ,width=10,height=s)
		print ( paste ("I create the figure file ",fname,"_Heatmap_GeneSymbols_",pvalue,".svg",sep=''))
		heatmap.2( as.matrix(geneNamesBased[,-1]), lwid = c( 1,6), lhei=c(1,5), cexRow=0.4,cexCol=0.7,col = greenred(30), trace="none", 
				margin=c(10, 10),dendrogram="row",scale="row",distfun=function (x) as.dist( 1- cor(t(x), method='pearson')),
				Colv=F, main=paste( analysis_name, pvalue ))
		dev.off()
	}
	else {
		print ( "Problems - P value cutoff to stringent - no gselected genes!" );
	}
}

removeBatch.NGSexpressionSet <- function( x, phenotype ){
	if ( x$batchRemoved==1) {
		return (x)
	}
	browser()
	exprs =  dataOBJ$cds
	null <- which ( exprs == 0)
	exprs[null]<- 1
	log <- log(exprs)
	svseq <-  ComBat(dat=filtered.log , mod=mod1, batch=x$samples[,phenotype], par.prior=TRUE, prior.plots=FALSE )
	svseq <- exp(log)
	svseq[null] = 0
	x$cds <- svseq
	x$batchRemoved = 1
	x
}
	

preprocess.NGSexpressionSet <- function (x) {
	if ( ! exists(where=x, 'vsdFull')){
		condition <- as.factor(x$samples$GroupName)
		print ( condition )
		x$cds <- newCountDataSet(x$data, condition)
		x$cds <- estimateSizeFactors(x$cds) 
		sizeFactors(x$cds)
		x$cds <- estimateDispersions(x$cds) 
		x$vsdFull = varianceStabilizingTransformation( x$cds )
	}
	x
}

anayse_working_set <- function ( dataOBJ, name,  p_values = c ( 0.1,  1e-2 ,1e-3,1e-4,1e-5, 1e-6, 1e-7, 1e-8 ),geneNameCol= "mgi_symbol", batchCorrect=NULL)  {
	dataOBJ <- preprocess.NGSexpressionSet ( dataOBJ )
	if ( ! is.null(batchCorrect) ){
		removeBatch.NGSexpressionSet( dataOBJ ,batchCorrect )
	}
	png(file=paste(dataOBJ$name,"_",version,'_interesting_samples_clean_up.png',sep=''), width=800, height=800) 
	plot(hclust(as.dist(1-cor(dataOBJ$data))),main=paste(dataOBJ$name,version, ' samples')) 
	dev.off()
	dataOBJ <- do_comparisons.NGSexpressionSet ( dataOBJ, geneNameCol=geneNameCol)
	#dataOBJ$expr <- exprs(dataOBJ$vsdFull)
	dataOBJ <- get_gene_list.NGSexpressionSet(dataOBJ,p_values, geneNameCol=geneNameCol)	
	dataOBJ
}